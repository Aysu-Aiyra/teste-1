const express = require ('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());

let cliente = [];
let pet = [];

app.get('/api/cliente', (req, res) => {
    res.json(cliente.slice(0,20));
});

app.get('/api/pet', (req, res) => {
    res.json(pet.slice(0,20));
});

app.post('/api/cliente', (req, res) => {
    const cliente = req.body;
    cliente.push(cliente);
    res.status(201).json(cliente);
});


app.post('/api/pet', (req, res) => {
    const pet = req.body;
    pet.push(pet);
    res.status(201).json(pet);
});

const port = process.env.PORT|| 5000;
app.listen(port, () => {
    console.log(`Servidor Rodando em http://localhost: ${port}`);
});
