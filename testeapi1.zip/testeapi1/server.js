const express = require('express');
const app = express();
const port = 3000;
// Middleware para parsear JSON
app.use(express.json());
// Array para amarzenar os usuarios 
let usuarios = [];
app.get('/usuarios', (req, res) => {
    res.send(usuarios);
})
app.post('/usuarios', (req, res) => {
    const {nome, cpf } = req.body;
    if (!nome ||!cpf) {
        return res.status(400).json({ error: 'Nome ou CPF inválidos' });
    }
    const novoUsuario = {id: usuarios.lenght + 1, nome, cpf};
    usuarios.push(novoUsuario);
    res.status(201).json(novoUsuario);
});
app.listen(port,() => {
    console.log(`Servidor Rodando em http://localhost: ${port}`);
    
});